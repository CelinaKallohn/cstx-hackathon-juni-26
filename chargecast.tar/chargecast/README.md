# ChargeCast

A small, self-improving forecasting tool for an EV charging hub. It starts from
the historic data you already have and gets better as you feed it each real day.

## The loop

```
1. predict   forecast tomorrow's hourly demand from everything known so far,
             given the prices you intend to charge
2. deploy    you run those prices for a day; customers charge
3. ingest    you hand it the day's actual kWh; it scores its own forecast,
             adds the day to its memory, and retrains
```

Each day the forecast reflects all prior days. The model never needs rebuilding
by hand — the same commands work on day 1 and on day 500.

## Two jobs, kept separate (and honest)

- **Baseline demand** — *learned from real data*. Starts as an hour x weekday
  profile (robust when data is thin) and automatically upgrades to a
  gradient-boosting model **only if** that model actually beats the profile on a
  holdout. On the supplied 2025 data the profile wins, so that's what it uses —
  forcing a heavier model in would add complexity without accuracy.
- **Price response** — *your assumption, until data replaces it*. You supply an
  elasticity % (how strongly customers shift charging when prices change).
  There is no price variation in the historic data, so this **cannot** be learned
  at the start — it's an input. Once you've run varied prices for ~30 days, the
  system estimates elasticity from real outcomes and switches over on its own.

## Install

```bash
pip install -e .          # from the package directory
# requires: pandas, numpy, scikit-learn, openpyxl
```

## Commands

Seed once with your historic files:
```bash
python -m chargecast.cli seed --state ./state \
  --lastgang Lastgang_Ladeinfrastruktur_Beispiel_Ladehub.xlsx \
  --spot Spotmarktpreis_.xlsx
```

Predict a day (prices.csv: columns `hour,price_ct`):
```bash
python -m chargecast.cli predict --state ./state --date 2026-06-18 --prices prices.csv
```
Output per hour: baseline_kwh, predicted_kwh (after price response), spot_ct,
price_ct, margin_eur (59ct-style revenue minus spot + BS Netz Arbeitspreis +
concession; the monthly Leistungspreis is not included here as it's capacity-based).

Ingest a real day (actuals.csv: columns `hourstamp,actual_kwh[,charged_price_ct,spot_ct]`):
```bash
python -m chargecast.cli ingest --state ./state --actuals actuals.csv
```
This scores yesterday's forecast *before* retraining (so the error is honest,
out-of-sample), appends the day, retrains, and logs accuracy.

Check progress:
```bash
python -m chargecast.cli status --state ./state
```

## State directory

```
state/history.csv        every hourly outcome accumulated
state/model.pkl          trained baseline + elasticity layer
state/accuracy_log.csv   one row per scored day (watch error shrink)
state/config.json        reference price, elasticity assumption, tariff rates
```

Edit `config.json` to change the reference price (default 59 ct/kWh), your
assumed elasticity %, or the grid tariff rates.

## Honest limitations

- The historic demand's day-to-day variation is mostly unexplained by the
  features available (hour-of-day and weekday carry nearly all the signal). The
  GBM upgrade path exists for when you add features with real signal — weather,
  holidays/events, station utilisation, the roaming/local split — or once dynamic
  pricing creates a price signal to learn from.
- The elasticity estimate is only as good as the price variation you actually
  run. Wider, more frequent price changes → a sharper estimate, faster.
- Margin is energy-only. Capacity charges (Leistungspreis) and fixed monthly
  fees are not modelled per-hour.
