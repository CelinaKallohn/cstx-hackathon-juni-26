"""ChargeCast command line.

Usage:
  python -m chargecast.cli seed     --state STATE --lastgang FILE.xlsx --spot FILE.xlsx
  python -m chargecast.cli predict  --state STATE --date YYYY-MM-DD --prices prices.csv [--out plan.csv]
  python -m chargecast.cli ingest   --state STATE --actuals actuals.csv
  python -m chargecast.cli status   --state STATE

prices.csv  : columns hour(0-23), price_ct      (and optional spot_ct)
actuals.csv : columns hourstamp, actual_kwh, charged_price_ct [, spot_ct]
"""
from __future__ import annotations
import argparse, sys, os
import numpy as np
import pandas as pd
from .store import Store, train, margin_per_hour
from .core import add_features


def _read_lastgang(path):
    df = pd.read_excel(path, sheet_name=0, header=1)
    col_kwh = [c for c in df.columns if 'kWh' in str(c)][0]
    df = df[['Ab-Datum', 'Ab-Zeit', col_kwh]].dropna(subset=['Ab-Zeit'])
    df.columns = ['date', 'time', 'kwh']
    df['kwh'] = pd.to_numeric(df['kwh'], errors='coerce')
    df['dt'] = pd.to_datetime(df['date'].astype(str) + ' ' + df['time'].astype(str))
    df['hourstamp'] = df['dt'].dt.floor('h')
    return df.groupby('hourstamp')['kwh'].sum().reset_index().rename(columns={'kwh': 'target_kwh'})


def _read_spot(path):
    sp = pd.read_excel(path, sheet_name=0)
    sp.columns = ['d', 'von', 'tz1', 'bis', 'tz2', 'price'][:len(sp.columns)]
    def hr(t): return t.hour if hasattr(t, 'hour') else int(round(float(t) * 24)) % 24
    sp['hour'] = sp['von'].apply(hr)
    sp['date'] = pd.to_datetime(sp['d'])
    sp['hourstamp'] = sp['date'] + pd.to_timedelta(sp['hour'], unit='h')
    return sp.groupby('hourstamp')['price'].mean().reset_index().rename(columns={'price': 'spot_ct'})


def cmd_seed(args):
    store = Store(args.state)
    dem = _read_lastgang(args.lastgang)
    spot = _read_spot(args.spot) if args.spot else None
    df = dem.merge(spot, on='hourstamp', how='left') if spot is not None else dem.assign(spot_ct=np.nan)
    df['spot_ct'] = df['spot_ct'].fillna(df['spot_ct'].median() if df['spot_ct'].notna().any() else 8.0)
    df['charged_price_ct'] = store.cfg['reference_price_ct']
    df['baseline_pred'] = np.nan
    store.append_history(df[['hourstamp', 'spot_ct', 'target_kwh', 'charged_price_ct', 'baseline_pred']])
    summary = train(store)
    print("Seeded and trained.")
    for k, v in summary.items():
        print(f"  {k}: {v}")


def cmd_predict(args):
    store = Store(args.state)
    m = store.load_model()
    if m is None:
        print("No model. Run seed first.", file=sys.stderr); sys.exit(1)
    base, elas = m['baseline'], m['elasticity']

    pr = pd.read_csv(args.prices)
    pr.columns = [c.strip().lower() for c in pr.columns]
    if 'hour' not in pr or 'price_ct' not in pr:
        print("prices.csv needs columns: hour, price_ct", file=sys.stderr); sys.exit(1)
    day = pd.to_datetime(args.date)
    hours = pd.DataFrame({'hour': range(24)})
    pr = hours.merge(pr, on='hour', how='left')
    pr['price_ct'] = pr['price_ct'].fillna(store.cfg['reference_price_ct'])

    hist = store.load_history()
    spot_by_hour = hist.assign(h=pd.to_datetime(hist['hourstamp']).dt.hour).groupby('h')['spot_ct'].mean()
    if 'spot_ct' in pr and pr['spot_ct'].notna().any():
        spot = pr['spot_ct'].fillna(pr['hour'].map(spot_by_hour)).values
    else:
        spot = pr['hour'].map(spot_by_hour).fillna(8.0).values

    frame = pd.DataFrame({'hourstamp': [day + pd.Timedelta(hours=h) for h in range(24)], 'spot_ct': spot})
    frame = add_features(frame)
    baseline = base.predict(frame)
    adjusted = elas.apply(baseline, pr['price_ct'].values, ref_price=store.cfg['reference_price_ct'])
    margin = margin_per_hour(adjusted, pr['price_ct'].values, spot, store.cfg)

    out = pd.DataFrame({
        'hourstamp': frame['hourstamp'],
        'hour': range(24),
        'price_ct': pr['price_ct'].values.round(2),
        'spot_ct': np.round(spot, 3),
        'baseline_kwh': np.round(baseline, 2),
        'predicted_kwh': np.round(adjusted, 2),
        'margin_eur': np.round(margin, 2),
    })
    dest = args.out or os.path.join(args.state, f'plan_{args.date}.csv')
    out.to_csv(dest, index=False)
    print(f"baseline model: {base.kind} | elasticity: {elas.mode} ({elas.active_pct:.1f}% per +10% price)")
    print(f"predicted total: {adjusted.sum():.0f} kWh | expected energy margin: EUR {margin.sum():.2f}")
    print(f"plan written: {dest}")


def cmd_ingest(args):
    store = Store(args.state)
    m = store.load_model()
    act = pd.read_csv(args.actuals)
    act.columns = [c.strip().lower() for c in act.columns]
    if 'hourstamp' not in act or 'actual_kwh' not in act:
        print("actuals.csv needs columns: hourstamp, actual_kwh", file=sys.stderr); sys.exit(1)
    act['hourstamp'] = pd.to_datetime(act['hourstamp'])
    act = act.rename(columns={'actual_kwh': 'target_kwh'})
    if 'charged_price_ct' not in act:
        act['charged_price_ct'] = store.cfg['reference_price_ct']

    # score yesterday's prediction BEFORE retraining (honest out-of-sample error)
    score = None
    if m is not None:
        base, elas = m['baseline'], m['elasticity']
        frame = add_features(act[['hourstamp']].assign(
            spot_ct=act['spot_ct'] if 'spot_ct' in act else 8.0))
        baseline = base.predict(frame)
        pred = elas.apply(baseline, act['charged_price_ct'].values, ref_price=store.cfg['reference_price_ct'])
        mae = float(np.mean(np.abs(pred - act['target_kwh'].values)))
        denom = act['target_kwh'].sum()
        mape = float(np.sum(np.abs(pred - act['target_kwh'].values)) / denom * 100) if denom > 0 else np.nan
        day = act['hourstamp'].dt.normalize().iloc[0]
        score = {'date': str(day.date()), 'mae_kwh': round(mae, 2),
                 'pct_error': round(mape, 1), 'actual_total_kwh': round(float(denom), 1),
                 'baseline_kind': base.kind, 'elasticity_mode': elas.mode}
        store.log_accuracy(score)

    if 'spot_ct' not in act:
        act['spot_ct'] = np.nan
    act['baseline_pred'] = np.nan
    store.append_history(act[['hourstamp', 'spot_ct', 'target_kwh', 'charged_price_ct', 'baseline_pred']])
    summary = train(store)

    if score:
        print(f"scored {score['date']}: {score['pct_error']}% day error ({score['mae_kwh']} kWh MAE/hr)")
    print("retrained on all data:")
    for k, v in summary.items():
        print(f"  {k}: {v}")


def cmd_status(args):
    store = Store(args.state)
    hist = store.load_history()
    acc = store.load_accuracy()
    m = store.load_model()
    days = pd.to_datetime(hist['hourstamp']).dt.normalize().nunique() if len(hist) else 0
    print(f"history: {len(hist)} hourly rows across {days} days")
    if m is not None:
        print(f"baseline model: {m['baseline'].kind}")
        print(f"elasticity: {m['elasticity'].mode} ({m['elasticity'].active_pct:.1f}% per +10% price), "
              f"varied-price days seen: {m['elasticity'].varied_days}")
    if len(acc):
        recent = acc.tail(7)
        print(f"recent day errors: {', '.join(str(x)+'%' for x in recent['pct_error'].tolist())}")
        print(f"mean error last {len(recent)} days: {recent['pct_error'].mean():.1f}%")


def main(argv=None):
    p = argparse.ArgumentParser(prog='chargecast')
    sub = p.add_subparsers(dest='cmd', required=True)
    s = sub.add_parser('seed'); s.add_argument('--state', required=True); s.add_argument('--lastgang', required=True); s.add_argument('--spot'); s.set_defaults(func=cmd_seed)
    s = sub.add_parser('predict'); s.add_argument('--state', required=True); s.add_argument('--date', required=True); s.add_argument('--prices', required=True); s.add_argument('--out'); s.set_defaults(func=cmd_predict)
    s = sub.add_parser('ingest'); s.add_argument('--state', required=True); s.add_argument('--actuals', required=True); s.set_defaults(func=cmd_ingest)
    s = sub.add_parser('status'); s.add_argument('--state', required=True); s.set_defaults(func=cmd_status)
    args = p.parse_args(argv)
    args.func(args)


if __name__ == '__main__':
    main()
