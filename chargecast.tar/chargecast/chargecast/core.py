"""Core forecasting engine for the charging hub.

Two jobs, kept separate on purpose:
  1. Baseline demand  - learned from real data (profile early, GBM once data is rich enough)
  2. Price response    - elasticity layer; uses your assumed % until enough
                         varied-price days exist to estimate it from data.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

FEATURES = ['spot_ct', 'hour', 'dayofweek', 'month', 'is_weekend',
            'dayofyear', 'trend', 'hour_sin', 'hour_cos']

GBM_MIN_DAYS = 120          # below this, the profile baseline is used
ELASTICITY_MIN_VARIED_DAYS = 30   # varied-price days needed to estimate elasticity
PRICE_VARIATION_THRESHOLD = 0.02  # >2% intraday price spread = a "varied-price" day


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    """df needs columns: hourstamp (datetime), spot_ct, target_kwh (target optional)."""
    df = df.copy()
    ts = pd.to_datetime(df['hourstamp'])
    df['hour'] = ts.dt.hour
    df['dayofweek'] = ts.dt.dayofweek
    df['month'] = ts.dt.month
    df['is_weekend'] = (ts.dt.dayofweek >= 5).astype(int)
    df['dayofyear'] = ts.dt.dayofyear
    df['trend'] = (ts - ts.min()).dt.total_seconds() / 3600.0
    df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
    df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
    return df


class BaselineModel:
    """Predicts price-neutral demand per hour.

    Starts as an hour x weekday profile (robust on little data), upgrades to a
    gradient-boosting model automatically once enough days have accumulated and
    the GBM actually beats the profile on a holdout.
    """

    def __init__(self):
        self.kind = 'profile'          # 'profile' or 'gbm'
        self.profile = None            # dict[(dow, hour)] -> mean kwh
        self.global_hour = None        # dict[hour] -> mean kwh (fallback)
        self.gbm = None
        self.n_days = 0

    def _fit_profile(self, df):
        g = df.groupby(['dayofweek', 'hour'])['target_kwh'].mean()
        self.profile = {k: float(v) for k, v in g.items()}
        gh = df.groupby('hour')['target_kwh'].mean()
        self.global_hour = {int(k): float(v) for k, v in gh.items()}

    def _profile_predict(self, df):
        out = []
        for _, r in df.iterrows():
            key = (int(r['dayofweek']), int(r['hour']))
            if key in self.profile:
                out.append(self.profile[key])
            else:
                out.append(self.global_hour.get(int(r['hour']), 0.0))
        return np.array(out)

    def fit(self, df: pd.DataFrame):
        """df: hourly rows with features + target_kwh."""
        df = df.dropna(subset=['target_kwh'])
        self.n_days = df['hourstamp'].dt.normalize().nunique() if 'hourstamp' in df else len(df)//24
        self._fit_profile(df)

        if self.n_days >= GBM_MIN_DAYS and len(df) > 500:
            self._try_gbm(df)
        else:
            self.kind = 'profile'
        return self

    def _try_gbm(self, df):
        from sklearn.ensemble import HistGradientBoostingRegressor
        from sklearn.metrics import mean_absolute_error
        d = df.sort_values('hourstamp')
        sp = int(len(d) * 0.85)
        tr, te = d.iloc[:sp], d.iloc[sp:]
        if len(te) < 50:
            self.kind = 'profile'; return
        gbm = HistGradientBoostingRegressor(
            max_iter=400, learning_rate=0.05, max_depth=6,
            l2_regularization=1.0, random_state=42)
        gbm.fit(tr[FEATURES], tr['target_kwh'])
        gbm_mae = mean_absolute_error(te['target_kwh'], np.clip(gbm.predict(te[FEATURES]), 0, None))
        # profile holdout
        prof_pred = self._profile_predict(te)
        prof_mae = mean_absolute_error(te['target_kwh'], prof_pred)
        # only adopt GBM if it genuinely beats the profile
        if gbm_mae < prof_mae * 0.98:
            gbm.fit(d[FEATURES], d['target_kwh'])  # refit on all data
            self.gbm = gbm
            self.kind = 'gbm'
        else:
            self.kind = 'profile'

    def predict(self, df: pd.DataFrame) -> np.ndarray:
        if self.kind == 'gbm' and self.gbm is not None:
            return np.clip(self.gbm.predict(df[FEATURES]), 0, None)
        return self._profile_predict(df)


class ElasticityLayer:
    """Applies price response to baseline demand.

    Mode 'assumed': uses the elasticity % you provide.
    Mode 'estimated': fitted from real varied-price history once available.
    Switches automatically.
    """

    def __init__(self, assumed_pct: float = 50.0):
        self.assumed_pct = assumed_pct          # % volume shift per +10% price
        self.estimated_pct = None
        self.mode = 'assumed'
        self.varied_days = 0
        self.ref_price = 59.0

    @property
    def active_pct(self) -> float:
        return self.estimated_pct if self.mode == 'estimated' and self.estimated_pct is not None else self.assumed_pct

    def maybe_estimate(self, history: pd.DataFrame):
        """history needs: hourstamp, charged_price_ct, target_kwh, baseline_pred.

        Counts varied-price days; once enough, regresses log(actual/baseline)
        on price deviation to estimate elasticity.
        """
        if history is None or len(history) == 0 or 'charged_price_ct' not in history:
            return
        h = history.dropna(subset=['charged_price_ct', 'target_kwh', 'baseline_pred']).copy()
        if len(h) == 0:
            return
        h['day'] = pd.to_datetime(h['hourstamp']).dt.normalize()
        spread = h.groupby('day')['charged_price_ct'].agg(lambda s: (s.max()-s.min())/max(s.mean(), 1e-6))
        self.varied_days = int((spread > PRICE_VARIATION_THRESHOLD).sum())
        if self.varied_days < ELASTICITY_MIN_VARIED_DAYS:
            return
        h = h[h['baseline_pred'] > 1.0]
        if len(h) < 100:
            return
        price_dev = (h['charged_price_ct'] - self.ref_price) / self.ref_price
        resp = np.log(np.clip(h['target_kwh'] / h['baseline_pred'], 1e-3, 50))
        mask = np.abs(price_dev) > 1e-4
        if mask.sum() < 50:
            return
        slope = np.polyfit(price_dev[mask], resp[mask], 1)[0]   # d ln(demand)/d (relative price)
        est = float(np.clip(-slope, 0, 5)) * 10 * 10  # convert to % per +10% price
        if 0 <= est <= 300:
            self.estimated_pct = round(est, 1)
            self.mode = 'estimated'

    def apply(self, baseline: np.ndarray, prices: np.ndarray, ref_price: float = None):
        ref = ref_price if ref_price is not None else self.ref_price
        pct = self.active_pct / 100.0
        prices = np.asarray(prices, float)
        price_dev = (prices - ref) / ref
        factor = 1 - pct * (price_dev / 0.10) * 0.10
        raw = np.clip(baseline * factor, 0, None)
        lost = baseline.sum() - raw.sum()
        cheap_w = np.clip(-price_dev, 0, None)
        result = raw.copy()
        if lost > 0 and cheap_w.sum() > 0:
            result = raw + lost * (cheap_w / cheap_w.sum())
        return result
