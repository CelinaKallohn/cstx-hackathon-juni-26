"""Persistence + economics for ChargeCast.

State lives in a directory:
  state/history.csv      - all hourly outcomes accumulated so far
  state/model.pkl        - trained BaselineModel + ElasticityLayer
  state/accuracy_log.csv - one row per day the model was scored
  state/config.json      - reference price, elasticity assumption, tariff
"""
from __future__ import annotations
import os, json, pickle
import numpy as np
import pandas as pd
from .core import BaselineModel, ElasticityLayer, add_features

DEFAULT_CONFIG = {
    "reference_price_ct": 59.0,
    "assumed_elasticity_pct": 50.0,
    # BS Netz tariff (Umspannung 20/0,4 kV, < 2500 h/a) used in the supplied calc
    "grid_arbeitspreis_ct_per_kwh": 8.24,
    "grid_leistungspreis_eur_per_kw_a": 19.76,
    "concession_ct_per_kwh": 0.11,
}


class Store:
    def __init__(self, path: str):
        self.path = path
        os.makedirs(path, exist_ok=True)
        self.cfg = self._load_cfg()

    # ---- config ----
    def _cfg_path(self): return os.path.join(self.path, 'config.json')
    def _load_cfg(self):
        p = self._cfg_path()
        if os.path.exists(p):
            with open(p) as f: return {**DEFAULT_CONFIG, **json.load(f)}
        with open(p, 'w') as f: json.dump(DEFAULT_CONFIG, f, indent=2)
        return dict(DEFAULT_CONFIG)
    def save_cfg(self):
        with open(self._cfg_path(), 'w') as f: json.dump(self.cfg, f, indent=2)

    # ---- history ----
    def _hist_path(self): return os.path.join(self.path, 'history.csv')
    def load_history(self) -> pd.DataFrame:
        p = self._hist_path()
        if not os.path.exists(p):
            return pd.DataFrame(columns=['hourstamp','spot_ct','target_kwh','charged_price_ct','baseline_pred'])
        df = pd.read_csv(p, parse_dates=['hourstamp'])
        return df
    def append_history(self, df: pd.DataFrame):
        cur = self.load_history()
        out = pd.concat([cur, df], ignore_index=True)
        out = out.drop_duplicates(subset=['hourstamp'], keep='last').sort_values('hourstamp')
        out.to_csv(self._hist_path(), index=False)
        return out

    # ---- model ----
    def _model_path(self): return os.path.join(self.path, 'model.pkl')
    def load_model(self):
        p = self._model_path()
        if os.path.exists(p):
            with open(p, 'rb') as f: return pickle.load(f)
        return None
    def save_model(self, obj):
        with open(self._model_path(), 'wb') as f: pickle.dump(obj, f)

    # ---- accuracy log ----
    def _acc_path(self): return os.path.join(self.path, 'accuracy_log.csv')
    def log_accuracy(self, row: dict):
        p = self._acc_path()
        df = pd.DataFrame([row])
        if os.path.exists(p):
            df = pd.concat([pd.read_csv(p), df], ignore_index=True)
        df.to_csv(p, index=False)
    def load_accuracy(self) -> pd.DataFrame:
        p = self._acc_path()
        return pd.read_csv(p) if os.path.exists(p) else pd.DataFrame()


def margin_per_hour(demand_kwh, charged_price_ct, spot_ct, cfg):
    """Energy margin per hour in EUR (excludes capacity/Leistungspreis, which is monthly)."""
    revenue = demand_kwh * charged_price_ct / 100.0
    energy_cost = demand_kwh * (spot_ct + cfg['grid_arbeitspreis_ct_per_kwh'] + cfg['concession_ct_per_kwh']) / 100.0
    return revenue - energy_cost


def train(store: Store) -> dict:
    """Retrain from scratch on all history. Returns a summary dict."""
    hist = store.load_history()
    if len(hist) == 0:
        raise RuntimeError("No history to train on. Seed with historic data first.")
    feat = add_features(hist.rename(columns={}).assign())
    feat['target_kwh'] = hist['target_kwh'].values
    # spot must be present for GBM features
    feat['spot_ct'] = hist['spot_ct'].fillna(hist['spot_ct'].median()).values

    base = BaselineModel().fit(feat)
    # baseline predictions over history (for elasticity estimation)
    hist = hist.copy()
    hist['baseline_pred'] = base.predict(feat)

    elas = ElasticityLayer(assumed_pct=store.cfg['assumed_elasticity_pct'])
    elas.ref_price = store.cfg['reference_price_ct']
    elas.maybe_estimate(hist)

    store.save_model({'baseline': base, 'elasticity': elas})
    # persist baseline_pred back into history so elasticity estimation compounds
    store.append_history(hist[['hourstamp','spot_ct','target_kwh','charged_price_ct','baseline_pred']])

    return {
        'baseline_kind': base.kind,
        'n_days': base.n_days,
        'elasticity_mode': elas.mode,
        'elasticity_active_pct': elas.active_pct,
        'elasticity_varied_days': elas.varied_days,
    }
