# Handoff notes

Context for continuing this project in a fresh session (e.g. Claude Code).
The README covers usage; this file covers *why things are the way they are* and
*what's next*. Read both.

## What this is

A self-improving daily demand forecaster for an EV charging hub. Daily loop:
predict tomorrow's hourly demand → deploy prices for the day → ingest the actual
kWh → score, accumulate, retrain. Same commands work on day 1 and day 500.

## Key decisions and the reasoning behind them

1. **Two jobs are deliberately separated.**
   - *Baseline demand* is learned from real data.
   - *Price response* is an elasticity layer, NOT learned at the start.
   The separation exists because the historic data has no price variation, so
   elasticity is unlearnable from it. Mixing the two would have produced a model
   that *looks* like it learned price response but didn't.

2. **The baseline uses an hour x weekday profile, not gradient boosting — on purpose.**
   We tested a HistGradientBoostingRegressor with real features (hour, weekday,
   month, season, spot price, trend). It did NOT beat a simple hour-average
   baseline (GBM MAE ~24.9 vs naive ~24.5; R^2 ~0.38; daily-level R^2 ~0.11).
   Conclusion: for this dataset the only real signal is hour-of-day plus a bit of
   weekday (weekends are busiest). Forcing in a GBM would be "ML as decoration."
   The code keeps a GBM upgrade path that auto-activates ONLY if it beats the
   profile on a holdout (see `BaselineModel._try_gbm`), so it switches itself on
   once richer features or more data justify it.

3. **Elasticity: assumed now, estimated later, auto-switch.**
   `ElasticityLayer` uses the user's assumed % until ~30 varied-price days exist,
   then estimates it from real outcomes via a log-demand-vs-price-deviation
   regression. Verified: fed data generated with a true 30% elasticity, it
   recovered ~25% and flipped to `estimated` mode.

4. **Retrain-from-scratch each day**, not incremental. At this scale (~9k hourly
   rows) it's fast and avoids drift; chosen as the robust default.

5. **Economics are energy-only.** Margin = 59ct revenue minus (spot + BS Netz
   Arbeitspreis 8.24 ct/kWh + concession 0.11 ct/kWh). Capacity charge
   (Leistungspreis) and fixed monthly fees are NOT modelled per hour.

## Honest limitations (don't paper over these)

- Day-to-day demand variation is largely unexplained by available features.
- The elasticity estimate is only as good as the price variation actually run.
- No uncertainty is reported anywhere yet — see pending work below.

## NEXT BUILD: see BUILD_PLAN_v2.md (this is the agreed work)

The user has confirmed a full redesign — option B, a unified model where price is
a normal column and its effect is a conjugate Bayesian coefficient that starts
from the user's prior and sharpens with varied-price data, plus a cost floor and
a demand-smoothing price recommender. The complete, step-by-step build plan with
all reasoning, the math, the CLI changes, and the build order is in
BUILD_PLAN_v2.md. Read that file first and build from it in the numbered order.

The section below is the older, narrower framing of the same idea, kept for
context. BUILD_PLAN_v2.md supersedes it.

## (Superseded) earlier note: make the elasticity layer properly Bayesian

This was discussed but NOT built. The current elasticity handling is frequentist:
a hard threshold gate (assumed % until day 30, then a `np.polyfit` point estimate).
It mimics the Bayesian *spirit* but is not Bayesian inference.

Desired change, scoped to the elasticity layer ONLY (leave the baseline profile
as is — Bayes adds ceremony without accuracy there):

- Replace the assumed-%-then-flip logic with a real **prior**: the user's assumed
  elasticity becomes a prior distribution with a stated confidence (e.g. a normal
  prior centered on their guess, width = how sure they are).
- Each varied-price day **updates a posterior** continuously — no hard switch at
  day 30. Early on the prior dominates; as evidence accumulates, data takes over.
  This makes the handoff smooth instead of a cliff.
- `predict` should report elasticity as a **central estimate plus a credible
  interval** that visibly narrows over time, and ideally propagate that
  uncertainty into the demand/margin forecast (e.g. predictive intervals).
- Implementation options: a conjugate Bayesian linear regression (lightweight, no
  new heavy deps) on log(actual/baseline) vs relative price deviation, or PyMC if
  full flexibility is wanted. Prefer the conjugate route first for simplicity.

Why it fits: strong domain prior + slow, noisy data is the textbook case for
Bayes, and the uncertainty is arguably more decision-relevant than the point
estimate for a pricing call.

## Where the real data lives

The .xlsx source files are NOT in this package (only code + small examples).
Before `chargecast seed`, copy the Lastgang and Spotmarktpreis xlsx into the
project or point `--lastgang` / `--spot` at their real paths.
